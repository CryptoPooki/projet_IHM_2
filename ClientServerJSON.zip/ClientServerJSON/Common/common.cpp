/**
 * Kevin Masson
 * L3 Informatique
 * S6 - Printemps 2017
 * Université de Strasbourg
 */
#include "common.h"


Common::Common()
{
}
