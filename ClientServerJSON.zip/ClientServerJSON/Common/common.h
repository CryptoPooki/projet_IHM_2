/**
 * Kevin Masson
 * L3 Informatique
 * S6 - Printemps 2017
 * Université de Strasbourg
 */
#ifndef COMMON_H
#define COMMON_H

#include "common_global.h"

class COMMONSHARED_EXPORT Common
{

public:
    Common();
};

#endif // COMMON_H
