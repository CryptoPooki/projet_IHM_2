/**
 * Kevin Masson
 * L3 Informatique
 * S6 - Printemps 2017
 * Université de Strasbourg
 */
#include "clientwin.h"
#include "ui_clientwin.h"

#include "ui_clientwin.h"
#include <Common/common.h>

#include <QtConcurrent/QtConcurrent>
#include <QJsonObject>
#include <QJsonDocument>
#include <QtDebug>
#include <QTextEdit>


ClientWin::ClientWin(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ClientWin),
    m_socket(new QLocalSocket(this))
{
    ui->setupUi(this);


    m_socket->connectToServer(SERVER_NAME);
    if (!m_socket->waitForConnected()) {
        qDebug() << "Cant connect";
        close();
        return;
    }

    connect(ui->textEdit, SIGNAL(textChanged()), this, SLOT(changementTexte()));
}

ClientWin::~ClientWin()
{
    m_socket->disconnectFromServer();
    delete ui;
}

void ClientWin::changementTexte(){
    QString txt = ui->textEdit->toPlainText();
    QJsonObject jsonObject ;
    jsonObject["txt"]=txt;
    QByteArray bytes = QJsonDocument(jsonObject).toJson(QJsonDocument::Compact)+"\n";
    if (m_socket!=NULL) {
      m_socket->write(bytes.data(), bytes.length());
      m_socket->flush();
    }
}
