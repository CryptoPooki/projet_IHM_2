/**
 * Kevin Masson
 * L3 Informatique
 * S6 - Printemps 2017
 * Université de Strasbourg
 */
#ifndef CLIENTWIN_H
#define CLIENTWIN_H

#include <QMainWindow>
#include <QLocalSocket>
#include <QFuture>

namespace Ui {
class ClientWin;
}

class ClientWin : public QMainWindow
{
    Q_OBJECT

public:
    explicit ClientWin(QWidget *parent = 0);
    ~ClientWin();

private slots:
    void changementTexte();

private:
    Ui::ClientWin *ui;
    QLocalSocket *m_socket;
    void serverMesssageLoop();
    bool m_running;
    QFuture<void> m_clientThreadLoop;
};

#endif // CLIENTWIN_H
