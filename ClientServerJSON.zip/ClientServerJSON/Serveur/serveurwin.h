/**
 * Kevin Masson
 * L3 Informatique
 * S6 - Printemps 2017
 * Université de Strasbourg
 */
#ifndef SERVEURWIN_H
#define SERVEURWIN_H

#include <QMainWindow>
#include <QLocalServer>
#include <QLocalSocket>
#include <QFuture>

namespace Ui {
class ServeurWin;
}

class ServeurWin : public QMainWindow
{
    Q_OBJECT

public:
    explicit ServeurWin(QWidget *parent = 0);
    ~ServeurWin();

private slots:
   void connectionFromClient();
   void clientDisconnected();

private:
    Ui::ServeurWin *ui;
    QLocalSocket *m_client=NULL;
    QLocalServer *m_server;
    bool m_running;
    void clientMessageLoop();
    QFuture<void> m_serverLoopThread;
};

#endif // SERVEURWIN_H
