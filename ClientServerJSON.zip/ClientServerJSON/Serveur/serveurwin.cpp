/**
 * Kevin Masson
 * L3 Informatique
 * S6 - Printemps 2017
 * Université de Strasbourg
 */
#include "serveurwin.h"
#include "ui_serveurwin.h"
#include <Common/common.h>

#include <QtConcurrent/QtConcurrent>
#include <QJsonObject>
#include <QJsonDocument>
#include <QtDebug>
#include <QLabel>

ServeurWin::ServeurWin(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ServeurWin),
    m_server(new QLocalServer(this))
{
    ui->setupUi(this);

    m_running=true;
    m_serverLoopThread=QtConcurrent::run(this, &ServeurWin::clientMessageLoop);

    QString serverName(SERVER_NAME);
    QLocalServer::removeServer(serverName);
    if (!m_server->listen(serverName)) {
      qDebug("Le serveur ne veut pas écouter..");
      return;
    }
    connect(m_server, SIGNAL(newConnection()), this, SLOT(connectionFromClient()));

}

ServeurWin::~ServeurWin()
{
    m_running=false;
    m_serverLoopThread.waitForFinished();
    delete ui;
}
void ServeurWin::connectionFromClient(){
  if(m_client) return; // Un seul client
  m_client= m_server->nextPendingConnection();
  connect(m_client, SIGNAL(disconnected()), m_client, SLOT(deleteLater()));
  connect(m_client, SIGNAL(disconnected()), this, SLOT(clientDisconnected()));
}

void ServeurWin::clientDisconnected(){
    m_client = NULL;
}

void ServeurWin::clientMessageLoop(){
    while (m_running){
      QDataStream in(m_client);
      if (in.atEnd()){ // Rien dans la file d'attente
        QThread::msleep(100); // On attend 1/10s et on continue
        continue;
      }
      QString str=QString(in.device()->readLine());
      QByteArray a=str.toUtf8();
      QJsonParseError error;
      QJsonDocument jDoc=QJsonDocument::fromJson(a, &error);
      QJsonObject jsonObject=jDoc.object();
      ui->label->setText(jsonObject.value("txt").toString());
    }
}
